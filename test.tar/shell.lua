local event = require("event")
local component = require("component")
local liked = require("liked")
local apps = require("apps")
local paths = require("paths")
local serialization = require("serialization")
local registry = require("registry")
local system = require("system")
local graphic = require("graphic")
local computer = require("computer")
local internet = require("internet")
internet.settings.timeout = 10

local screen = ...

if _G.lugMarketScreen and _G.lugMarketScreen ~= screen then
    event.wait()
    return
end

_G.lugMarketScreen = screen
_G.lugmarketPort = 4561
_G.lugmarketMsg = "lugmarket_msg"

_G.host = "http://176.53.161.98:4045"
_G.updateHost = _G.host .. "/e2d8fefb-dd72-4c9a-be85-6db41a92b3db/"
_G.postUrl = _G.host .. "/d86a22ef-ad92-45b5-bd89-9d6c59e0c63f/"
_G.updateFile = _G.updateHost .. "files.tbl"
_G.dbFile = _G.updateHost .. "data.dat"

-------------------------------------------------------- system settings

graphic.setDepth(screen, 4)
registry.shadowMode = "full"
registry.shadowType = "advanced"
registry.bufferType = "hardware"
--registry.bufferType = "none"
liked.applyBufferType()

-------------------------------------------------------- modem check & wakeup

local appFolder = paths.concat(paths.path(system.getSelfScriptPath()), "LUGMarket.app")
local defaultConfigPath = paths.concat(appFolder, "default.dat")
local defaultConfig = serialization.load(defaultConfigPath)
local config = registry.new("lugmarket.dat", defaultConfig)
_G.lugmarketConfig = config

-------------------------------------------------------- modem check & wakeup

local modem = component.modem or error("connect the wired modem!")
if modem.isWireless() then
    error("wireless modem is not support")
end

modem.close()
modem.open(_G.lugmarketPort)
modem.setWakeMessage(_G.lugmarketMsg, true)

local function sendToServer()
    local card = internet.cardProxy()
    if card then
        card.request(_G.postUrl, serialization.serialize(config.data))
    end
end

function _G.lugmarketSend()
    modem.broadcast(_G.lugmarketPort, _G.lugmarketMsg, config.data.version, serialization.serialize(config.data))
end

local function getTable(url)
    if internet.card() then
        local files = internet.get(url)
        if files then
            files = serialization.unserialize(files)
            if files then
                return files
            end
        end
    end
end

function _G.updateCheck()
    local files = getTable(_G.updateFile)
    if files then
        if not registry.lugver or registry.lugver ~= files.version then
            --local downloads = {}
            for _, file in ipairs(files) do
                --table.insert(downloads, {_G.updateHost .. file, paths.concat("/system/bin", file)})
                internet.download(_G.updateHost .. file, paths.concat("/system/bin", file))
            end
            --internet.downloads(downloads)
            registry.lugver = files.version
            computer.shutdown("fast")
        end
    end
end

function _G.syncCheck()
    local files = getTable(_G.dbFile)
    if files then
        if files.version > config.data.version then
            config.data = files
            config.save()
        elseif files.version < config.data.version then
            sendToServer()
        end
    end
end

event.timer(3, function ()
    _G.lugmarketSend()
end, math.huge)

event.listen("modem_message", function (_, uuid, sender, port, dist, title, version, cfg)
    if title == _G.lugmarketMsg then
        if version > config.data.version then
            config.data = serialization.unserialize(cfg)
            config.save()
        end
    end
end)

-------------------------------------------------------- event hook

event.hyperHook(function (...)
    local eventData = {...}
    if eventData[1] == "key_down" or eventData[1] == "key_up" then
        if _G.lugMarketUser and eventData[5] ~= _G.lugMarketUser then
            eventData[1] = "skipped_" .. eventData[1]
        end
    elseif eventData[1] == "touch" or eventData[1] == "scroll" or eventData[1] == "drag" or eventData[1] == "drop" then
        if _G.lugMarketUser and eventData[6] ~= _G.lugMarketUser then
            eventData[1] = "skipped_" .. eventData[1]
        end
    end
    return table.unpack(eventData)
end)

-------------------------------------------------------- redstone wakeup

for addrs in component.list("redstone", true) do
    component.invoke(addrs, "setWakeThreshold", 1)
end

-------------------------------------------------------- running market shell

_G.syncCheck()
_G.updateCheck()

while true do
    apps.execute("LUGMarket", screen)
    for i = 1, 3 do
        computer.beep(300, 0.5)
        os.sleep(0.1)
    end
end