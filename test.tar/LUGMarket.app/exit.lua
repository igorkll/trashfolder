local graphic = require("graphic")
graphic.cursorColor = nil
graphic.selectColor = nil